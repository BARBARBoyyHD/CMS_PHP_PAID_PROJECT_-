<?php
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'seblaktasti_db';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);